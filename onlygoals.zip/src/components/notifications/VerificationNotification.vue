<script setup>


</script>

<template>
  <div class="verification-notification">
    <div class="verification-notification__text">Для завершения регистрации верефицируйтесь через отправленное нами письмо</div>
    <button class="btn btn--extra-small btn--light verification-notification__btn">Отправить еще раз</button>
  </div>
</template>

