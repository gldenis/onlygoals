<script setup>

</script>

<template>
  <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path fill-rule="evenodd" clip-rule="evenodd" d="M6.94027 3.53086C7.42985 2.74752 8.57068 2.74753 9.06026 3.53086L13.1581 10.0875C13.6785 10.92 13.0799 12 12.0981 12H3.90239C2.92059 12 2.32204 10.92 2.84239 10.0875L6.94027 3.53086Z" fill="white" fill-opacity="0.32"/>
  </svg>

</template>

<style scoped lang="scss">

</style>
