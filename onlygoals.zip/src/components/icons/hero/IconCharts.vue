<template>
  <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M2.25 4.125C2.25 3.08947 3.08947 2.25 4.125 2.25H6.75V17.25H4.125C3.08947 17.25 2.25 16.4105 2.25 15.375V4.125Z" fill="white" fill-opacity="0.8" />
    <path d="M9 2.25H15V19.875C15 20.9105 14.1605 21.75 13.125 21.75H10.875C9.83947 21.75 9 20.9105 9 19.875V2.25Z" fill="white" fill-opacity="0.8" />
    <path d="M19.875 2.25H17.25V14.25H19.875C20.9105 14.25 21.75 13.4105 21.75 12.375V4.125C21.75 3.08947 20.9105 2.25 19.875 2.25Z" fill="white" fill-opacity="0.8" />
  </svg>
</template>
