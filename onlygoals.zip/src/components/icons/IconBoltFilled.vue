<template>
  <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path fill-rule="evenodd"
          clip-rule="evenodd"
          d="M9.991.752c.268.15.4.462.319.758L9.04 6.168h4.627a.667.667 0 0 1 .487 1.122l-7 7.5a.667.667 0 0 1-1.13-.63L7.294 9.5H2.667a.667.667 0 0 1-.488-1.121l7-7.5a.667.667 0 0 1 .812-.128Zm-5.79 7.416h3.966a.667.667 0 0 1 .643.842l-.79 2.898 4.113-4.407H8.166a.667.667 0 0 1-.643-.842l.79-2.898L4.2 8.168Z"
          fill="url(#a)"></path>
    <defs>
      <linearGradient id="a" x1="2" y1="15.001" x2="17.621" y2="7.943" gradientUnits="userSpaceOnUse">
        <stop stop-color="#FF7AC6"></stop>
        <stop offset=".23" stop-color="#FFBD7A" stop-opacity=".8"></stop>
        <stop offset=".5" stop-color="#C37AFF" stop-opacity=".94"></stop>
        <stop offset=".75" stop-color="#4D67FF"></stop>
        <stop offset=".99" stop-color="#7AFFF8" stop-opacity=".82"></stop>
      </linearGradient>
    </defs>
  </svg>

</template>
