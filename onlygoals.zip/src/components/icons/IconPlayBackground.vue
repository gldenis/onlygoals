<script setup>

</script>

<template>
  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
    <path fill-rule="evenodd" clip-rule="evenodd" d="M1.5 12C1.5 6.20101 6.20101 1.5 12 1.5C17.799 1.5 22.5 6.20101 22.5 12C22.5 17.799 17.799 22.5 12 22.5C6.20101 22.5 1.5 17.799 1.5 12ZM11.1844 15.791L15.978 12.795C16.5655 12.4278 16.5655 11.5722 15.978 11.205L11.1844 8.20898C10.56 7.81872 9.75 8.26764 9.75 9.00398V14.996C9.75 15.7324 10.56 16.1813 11.1844 15.791Z" fill="white" fill-opacity="0.8"/>
  </svg>
</template>

<style scoped lang="scss">

</style>
