<template>
  <svg width="44" height="57" viewBox="0 0 44 57" fill="none" xmlns="http://www.w3.org/2000/svg">
    <g filter="url(#filter0_bd_4176_44309)">
      <path d="M22 1C33.603 1 43 10.4547 43 22.1064C43 32.1744 35.9857 40.5991 26.594 42.706L23.4438 47.241L22 1ZM22 1C10.397 1 1 10.4547 1 22.1064C1 32.1744 8.01428 40.5991 17.406 42.706L20.5563 47.241L22 1ZM22.8168 47.7975C23.0677 47.6652 23.2819 47.4744 23.4426 47.2426H20.5574C20.7181 47.4744 20.9323 47.6652 21.1832 47.7975C21.4346 47.9302 21.7149 48 22 48C22.2851 48 22.5654 47.9302 22.8168 47.7975Z" fill="white" fill-opacity="0.12" stroke="url(#paint0_linear_4176_44309)" stroke-width="2"/>
      <path d="M23.4999 29.5C23.4999 30.3284 22.8283 31 21.9999 31C21.1715 31 20.4999 30.3284 20.4999 29.5C20.4999 28.6716 21.1715 28 21.9999 28C22.8283 28 23.4999 28.6716 23.4999 29.5Z" fill="#E9EAEC"/>
      <path fill-rule="evenodd" clip-rule="evenodd" d="M22 16C20.3431 16 19 17.3431 19 19C19 19.6213 18.4963 20.125 17.875 20.125C17.2537 20.125 16.75 19.6213 16.75 19C16.75 16.1005 19.1005 13.75 22 13.75C24.8995 13.75 27.25 16.1005 27.25 19C27.25 21.5133 25.4839 23.6142 23.125 24.1292V25.375C23.125 25.9963 22.6213 26.5 22 26.5C21.3787 26.5 20.875 25.9963 20.875 25.375V23.125C20.875 22.5037 21.3787 22 22 22C23.6569 22 25 20.6569 25 19C25 17.3431 23.6569 16 22 16Z" fill="#E9EAEC"/>
      <path d="M24 55C24 53.8954 23.1046 53 22 53C20.8954 53 20 53.8954 20 55C20 56.1046 20.8954 57 22 57C23.1046 57 24 56.1046 24 55Z" fill="url(#paint1_linear_4176_44309)"/>
    </g>
    <defs>
      <filter id="filter0_bd_4176_44309" x="-20" y="-20" width="84" height="97" filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB">
        <feFlood flood-opacity="0" result="BackgroundImageFix"/>
        <feGaussianBlur in="BackgroundImageFix" stdDeviation="10"/>
        <feComposite in2="SourceAlpha" operator="in" result="effect1_backgroundBlur_4176_44309"/>
        <feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha"/>
        <feMorphology radius="64" operator="erode" in="SourceAlpha" result="effect2_dropShadow_4176_44309"/>
        <feOffset dx="-8" dy="4"/>
        <feGaussianBlur stdDeviation="6"/>
        <feColorMatrix type="matrix" values="0 0 0 0 0.0941176 0 0 0 0 0.0941176 0 0 0 0 0.160784 0 0 0 0.4 0"/>
        <feBlend mode="multiply" in2="effect1_backgroundBlur_4176_44309" result="effect2_dropShadow_4176_44309"/>
        <feBlend mode="normal" in="SourceGraphic" in2="effect2_dropShadow_4176_44309" result="shape"/>
      </filter>
      <linearGradient id="paint0_linear_4176_44309" x1="-18.2566" y1="24.4457" x2="62.0003" y2="24.76" gradientUnits="userSpaceOnUse">
        <stop offset="0.246031" stop-color="#3073FA"/>
        <stop offset="0.5" stop-color="#F2883C"/>
        <stop offset="0.761731" stop-color="#933CEA"/>
      </linearGradient>
      <linearGradient id="paint1_linear_4176_44309" x1="17.9743" y1="54.9952" x2="26" y2="55.0305" gradientUnits="userSpaceOnUse">
        <stop offset="0.246031" stop-color="#3073FA"/>
        <stop offset="0.5" stop-color="#F2883C"/>
        <stop offset="0.761731" stop-color="#933CEA"/>
      </linearGradient>
    </defs>
  </svg>

</template>

<style scoped lang="scss">

</style>
