<script setup>

</script>

<template>
  <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 12 12" fill="none">
    <path d="M10.3125 6.5625C10.6232 6.5625 10.875 6.31066 10.875 6C10.875 5.68934 10.6232 5.4375 10.3125 5.4375C5.0984 5.4375 7.26067 5.4375 1.6875 5.4375C1.37684 5.4375 1.125 5.68934 1.125 6C1.125 6.31066 1.37684 6.5625 1.6875 6.5625C7.11473 6.5625 4.49477 6.5625 10.3125 6.5625Z" fill="#E9EAEC"/>
  </svg>
</template>

<style scoped lang="scss">

</style>
