<script setup>

</script>

<template>
  <div class="support">
    <img src="@/assets/img/support.png" alt="">
  </div>
</template>

<style scoped lang="scss">
.support {
  position: fixed;
  bottom: rem(40);
  right: rem(40);
  z-index: 3;
}
</style>
